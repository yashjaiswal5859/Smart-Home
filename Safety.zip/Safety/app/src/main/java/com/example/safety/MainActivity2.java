package com.example.safety;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity2 extends AppCompatActivity {

private WebView webView;
Button register,on,off;
LinearLayout ll;
int z=0;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,

                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main2);
        //WebView myWebView = new WebView(R.id.w1);
        webView = (WebView) findViewById(R.id.w1);

        webView.setWebViewClient(new WebViewClient());
        webView.setVisibility(webView.INVISIBLE);
        ll=(LinearLayout) findViewById(R.id.ll);
        register = (Button) ll.findViewById(R.id.button3);
        on = (Button) ll.findViewById(R.id.button);
        off = (Button) ll.findViewById(R.id.button2);

        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                z=(z+1)%127;
                webView.setVisibility(webView.VISIBLE);
                webView.loadUrl("http://192.168.43.35/"+z);
            }
        });
        on.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                webView.setVisibility(webView.INVISIBLE);
                webView.loadUrl("http://192.168.43.35/a");
            }
        });
        off.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                webView.setVisibility(webView.INVISIBLE);
                webView.loadUrl("http://192.168.43.35/b");
            }
        });


        //(myWebView);


    }
}